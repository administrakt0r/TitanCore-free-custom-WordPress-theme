<?php
/**
 * Template part for displaying a message when no content is found.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$is_search_query  = is_search();
$is_archive_query = is_archive();
$search_query     = get_search_query();
$icon_name        = $is_search_query ? 'search-x' : 'inbox';
?>
<section class="py-12 md:py-16 text-center flex flex-col items-center justify-center border-x border-b border-border bg-card/50 px-6 space-y-6">
	<span class="inline-flex h-12 w-12 items-center justify-center rounded-full bg-muted border border-border text-muted-foreground shadow-sm" aria-hidden="true">
		<?php echo titancore_get_icon( $icon_name, 'w-6 h-6' ); ?>
	</span>

	<div class="space-y-2 max-w-md">
		<h2 class="text-2xl md:text-3xl font-bold tracking-tight">
			<?php
			if ( $is_search_query ) {
				esc_html_e( 'No results found', 'titancore' );
			} elseif ( $is_archive_query ) {
				esc_html_e( 'No posts in this archive', 'titancore' );
			} else {
				esc_html_e( 'Nothing found', 'titancore' );
			}
			?>
		</h2>
		<p class="text-muted-foreground text-sm md:text-base leading-relaxed text-balance">
			<?php
			if ( $is_search_query && ! empty( $search_query ) ) {
				/* translators: %s: Search term */
				printf( esc_html__( 'Sorry, we couldn\'t find any results matching "%s". Try adjusting your search query or explore popular topics below.', 'titancore' ), esc_html( $search_query ) );
			} elseif ( $is_archive_query ) {
				esc_html_e( 'There are currently no published articles in this archive. Try searching or browse recent posts.', 'titancore' );
			} else {
				esc_html_e( 'There are no posts matching your request. Try searching or browse our recent articles.', 'titancore' );
			}
			?>
		</p>
	</div>

	<div class="w-full max-w-sm pt-1">
		<?php get_search_form(); ?>
	</div>

	<?php
	$categories = titancore_get_top_categories( 6 );
	if ( ! empty( $categories ) ) : ?>
		<div class="pt-2 w-full max-w-md">
			<span class="block text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3"><?php esc_html_e( 'Popular Topics', 'titancore' ); ?></span>
			<div class="flex flex-wrap items-center justify-center gap-2">
				<?php foreach ( $categories as $category ) : ?>
					<a href="<?php echo esc_url( get_category_link( $category->term_id ) ); ?>" class="tc-post-card__term hover:border-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
						<?php echo esc_html( $category->name ); ?>
						<span class="ml-1.5 opacity-60 text-[10px] font-mono">(<?php echo esc_html( absint( $category->count ) ); ?>)</span>
					</a>
				<?php endforeach; ?>
			</div>
		</div>
	<?php endif; ?>

	<?php
	$recent_post_ids = titancore_get_recent_posts( 3 );
	if ( ! empty( $recent_post_ids ) ) :
		$recent_posts = get_posts( array(
			'post__in'               => $recent_post_ids,
			'orderby'                => 'post__in',
			'posts_per_page'         => count( $recent_post_ids ),
			'ignore_sticky_posts'    => true,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
		) );
		if ( ! empty( $recent_posts ) ) : ?>
			<div class="pt-6 border-t border-border/60 w-full max-w-3xl text-left">
				<h3 class="text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center mb-4"><?php esc_html_e( 'Recent Articles', 'titancore' ); ?></h3>
				<div class="grid sm:grid-cols-3 gap-3">
					<?php foreach ( $recent_posts as $recent_post ) : ?>
						<a href="<?php echo esc_url( get_permalink( $recent_post->ID ) ); ?>" class="group block rounded-lg border border-border bg-card p-4 hover:bg-accent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
							<span class="block text-sm font-semibold leading-snug group-hover:text-foreground line-clamp-2"><?php echo esc_html( get_the_title( $recent_post->ID ) ); ?></span>
							<span class="block text-xs text-muted-foreground mt-2"><?php echo esc_html( get_the_date( '', $recent_post->ID ) ); ?></span>
						</a>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif; ?>
	<?php endif; ?>

	<div class="pt-2">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="inline-flex h-10 items-center justify-center rounded-lg bg-primary px-5 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
			<?php esc_html_e( 'Back to Home', 'titancore' ); ?>
		</a>
	</div>
</section>
