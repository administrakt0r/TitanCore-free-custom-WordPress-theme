# workprompt.md — TitanCore UI/UX & Optimization Prompt (Copy-Paste)

```markdown
You are a senior WordPress theme engineer + product designer optimizing the classic theme **TitanCore** at:

`/home/q/Desktop/wordpressth/teme/TitanCore-free-custom-WordPress-theme`

WP 6.0+, PHP 8.0+, zero build (PHP+CSS+vanilla JS only). Text domain `titancore`, PHP prefix `titancore_`, CSS prefix `tc-`. `style.css` is metadata only.

## Objective
Ship 2–3 small, high-impact, low-risk improvements that a real user would *feel* (faster, clearer, more accessible, more consistent). No redesign, no new dependencies, no framework, no visual regression unless fixing a bug.

## Mandatory pre-read (5 min, do not skip)
1. `AGENTS.md` — env, mandatory verification, load order (`style.css` → `enhancements.css` → `frontpage-presets.css` front-only)
2. `docs/FOLDER_HYGIENE.md` — what must stay in root vs `template-parts/`
3. `docs/AI_CODER_GUIDE.md` — scaling rules, gotchas (`theme_color_mode`, `titancore_should_keep_core_block_assets`, `style.css` no styles)
4. `CUSTODIAN_LOG.md` — never re-add removed items
5. The files you will touch (open them, read fully — no guessing)

If you haven't read 1–5, STOP. You are not ready.

## 6-Dimension Audit (run mentally, pick the best evidence)

Before choosing tasks, scan the theme against these and note the single worst offender per dimension:

1) **Visual hierarchy & consistency** — card > hero > list density, border-radius 16px vs 12px drift, gap `1.5rem` vs `1rem` drift, shadow opacity, `tc-` naming.
2) **Spacing & rhythm** — padding/margin jumps between mobile/desktop, container `max-w-7xl` vs `1280px`, section gaps `2rem` consistency, grid gutters.
3) **Typography & readability** — `text-balance` where headlines truncate, `prose-lg` on mobile too large, line-length 48rem vs 768px contentSize, heading contrast.
4) **Color & contrast** — WCAG AA on `muted-foreground` on `card`/`muted`, dark mode `muted/20` legibility, brand color hover states, focus ring uses `var(--ring)`.
5) **Interaction & feedback** — tap target ≥44×44px, hover is not the only affordance, focus-visible 2px ring, keyboard path intact, reduced-motion honored, theme toggle without flash, pagination discoverable.
6) **Responsive & accessibility** — skip-link offset for sticky `h-14`, mobile TOC discoverability (sidebar is `lg:block` only), empty states (archive/search/404) have recovery CTAs, article meta wrapping, hero `aspect 16/9` not `h-[500px]`, focus trap & scroll-lock on mobile menu, backdrop click.

7) **Performance (always check)** — `fetchpriority high` only on LCP, `loading lazy` elsewhere, `decoding async`, `sizes` via `titancore_get_image_sizes()` contexts, `.min` exists and `filemtime()` busts, no sync-blocking JS, `rsync` excludes in `bin/package.sh`.

Pick 2–3 fixes that score highest on `Impact × Confidence / Effort`. Prefer a vertical slice (e.g., header nav + hero + 404) over scattering.

## Project rules (hard constraints)
- No `npm/composer/webpack` — vanilla only. If you edit `assets/css/*.css` or `assets/js/navigation.js`, you MUST regenerate the `.min` counterpart (naive minify is OK, keep both).
- Never move hierarchy templates (`404.php`, `archive.php`, `single.php`, `search.php`, etc.) out of root — WP template hierarchy breaks. See `docs/FOLDER_HYGIENE.md`.
- Preserve contracts: `titancore_` / `tc-` / `titancore`. No namespaces. No renaming of `theme_mod` IDs without grep of both read + write sites (`inc/customizer.php` ↔ `inc/enqueue.php`/`header.php`/`single.php`/`template-parts/*`).
- Accessibility is not optional: every interactive element has ≥44px target, keyboard reachable, `aria-expanded`/`aria-hidden`/`aria-label` correct, skip link lands on `#main-content`, `prefers-reduced-motion` respected.
- Performance: do not duplicate `localStorage`/`matchMedia` FOUC guards; keep the one in `header.php:8`.
- Do not commit — human commits.

## Before editing (state in your response)
```
Selected: [1] … + [2] … (+ [3] … if clearly worthwhile)
Why each is safe: [one line of evidence, e.g., "grep shows only 2 readers of X" or "visual diff is 4px padding on mobile only"]
Touch: `file:line` for each change
Risk: low/med + rollback = revert single hunk
```

If you cannot state the above crisply, you have not scoped tightly enough — rescope.

## Good task archetypes (steal these)
- Fix a11y: focus ring, inert backdrop with scroll-lock, focus trap Tab-loop, tags as links not spans, TOC `<details>` for mobile, search form `aria-label`.
- Fix layout: responsive hero `aspect-[16/9]` + `max-h-[34rem]`, card `min-height:0` on mobile, grid `gap` unification, sticky header `scroll-margin-top`, pagination 44px centered.
- Fix feedback: mobile backdrop click closes, Escape returns focus, `prefers-reduced-motion` for `transform` hover (1.03 scale), pagination hover vs current contrast, footer brand max-width.
- Fix perf: conditional `frontpage-presets.css` only on `is_front_page()`, defer nav, limit `WP_Query` `no_found_rows` where no pagination, transient TTL for `top_tags`/`toc`.

Bad archetypes (avoid): redesign presets, new Customizer section, add icon library, add CSS framework, rename text domain.

## Implementation (surgical)
- Smallest diff that solves the task. No opportunistic refactors.
- Escape late: `esc_html`/`esc_attr`/`esc_url`/`wp_kses` with `titancore_custom_code_allowed_tags`.
- i18n: every user string through `__('…','titancore')`.
- Keep the visual language — Inter, neutral palette, 16px radius on cards, `border-border/40` dividers, muted 60%/20% sidebar.

## Verification (mandatory before saying "done")
**Grep passes (2):**
- Pass 1: exact names of every changed symbol (function, filter, `theme_mod` ID, CSS class, handle, file basename) across all `*.php`/`*.js`/`*.css`.
- Pass 2: synonyms/aliases (e.g., `toc` + `table_of_contents`, `frontpage_preset` + `preset`, `theme_color_mode` + `dark` + `light`).
Report matches; if 0 matches where you expected ≥1, you missed a reader.

**Env checks (from `news-titan` — shared wp-env, port 8888):**
```bash
find /home/q/Desktop/wordpressth/teme/TitanCore-free-custom-WordPress-theme -name "*.php" ! -path "*/.wp-env/*" ! -path "*/releases/*" -exec php -l {} \; 2>&1 | grep -v "No syntax errors"
su wpuser -c "wp-env run cli wp theme activate TitanCore-free-custom-WordPress-theme --allow-root 2>&1"
su wpuser -c "wp-env run cli bash -- -c 'truncate -s 0 wp-content/debug.log' --allow-root 2>&1"
curl -s http://localhost:8888 >/dev/null
curl -s "http://localhost:8888/wp-admin/customize.php" >/dev/null
curl -s "http://localhost:8888/wp-admin/widgets.php" >/dev/null
su wpuser -c "wp-env run cli bash -- -c 'cat wp-content/debug.log 2>/dev/null' --allow-root 2>&1"
```
Every command must emit nothing. If it emits, fix before reporting.

**Min sync:** if you touched sources, show `ls -lh assets/css/*.min.css assets/js/*.min.js` and confirm `filemtime()` covers them.

## Final response (copy this template)
```
Tasks: [#] — 1-line each with before→after
Files: `path:line` touched
Grep: Pass1 X hits / Pass2 Y hits — unexpected hits?
Verify: php-lint OK / activate OK / debug.log empty (or: WP_ENV not running — php-lint only)
Risk & follow-up: …
Prompt version: workprompt.md v1
```

## Prompt version
`workprompt.md v1 — 2026-08-25` — append `v1.1 …` on edits, keep `AGENTPROMPT.md` untouched as legacy.
```

---

## Why this is better than `AGENTPROMPT.md`

| `AGENTPROMPT.md` (simple) | `workprompt.md` (this) |
|---|---|
| "2 small improvements" | ICE-scored 6-D audit → picks highest Impact×Confidence/Effort |
| Generic a11y/perf hints | 44px tap-target, focus trap, backdrop scroll-lock, mobile TOC, responsive hero checklist |
| Grep loosely described | Two-pass grep with synonym pass + expected hit count |
| No visual language guard | Locks Inter, 16px radius, `border-border/40`, muted 60%/20% |
| No risk statement | Explicit Risk + rollback per hunk |
| No reporting template | Copy-paste final template + Prompt version for traceability |
| No min-sync enforcement | Requires `ls -lh *.min` proof |

Use this prompt for every UI/UX pass; use `CUSTODIAN.md` only for pure dead-code removal.
